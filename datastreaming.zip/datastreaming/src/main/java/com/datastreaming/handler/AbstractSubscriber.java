package com.datastreaming.handler;

import com.datastreaming.otel.Tracing;
import io.netty.buffer.ByteBuf;
import io.opentelemetry.api.GlobalOpenTelemetry;
import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.StatusCode;
import io.opentelemetry.context.Scope;
import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ratpack.core.handling.Context;

public abstract class AbstractSubscriber implements Subscriber<ByteBuf> {

    private final Logger logger = LoggerFactory.getLogger(AbstractSubscriber.class);

    protected Context ctx;
    protected Subscription subscription;
    protected boolean isError;
    protected Throwable cause;
    protected String key;
    protected String topic;
    protected String topicName;
    protected String pulsarTenantName;
    protected String pulsarTenantNamespace;

    public String getTenantName() {
        return tenantName;
    }

    public void setTenantName(String tenantName) {
        this.tenantName = tenantName;
    }

    protected String tenantName;

    public String getPulsarTenantName() {
        return pulsarTenantName;
    }

    public void setPulsarTenantName(String pulsarTenantName) {
        this.pulsarTenantName = pulsarTenantName;
    }

    public String getPulsarTenantNamespace() {
        return pulsarTenantNamespace;
    }

    public void setPulsarTenantNamespace(String pulsarTenantNamespace) {
        this.pulsarTenantNamespace = pulsarTenantNamespace;
    }

    private static final String DEFAULT_CHARSET = "UTF-8";

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    protected AbstractSubscriber(Context ctx) {
        this.ctx = ctx;
    }

    protected AbstractSubscriber() {
    }

    @Override
    public void onSubscribe(Subscription subscription) {
        logger.info("onSubscribe");
        Span span = Tracing.getTracer().spanBuilder("AbstractSubscriber.onSubscribe")
                .setParent(io.opentelemetry.context.Context.current().with(Span.current()))
                .startSpan();
        try (Scope scope = span.makeCurrent()) {
            this.subscription = subscription;
            subscription.request(1);
        } catch (Throwable t) {
            span.setStatus(StatusCode.ERROR, "AbstractSubscriber.onSubscribe child span error");
        } finally {
            span.end();
        }
    }

    @Override
    public void onNext(ByteBuf byteBuf) {
        logger.info("onNext");
        Span span = Tracing.getTracer().spanBuilder("AbstractSubscriber.onNext")
                .setParent(io.opentelemetry.context.Context.current().with(Span.current()))
                .startSpan();
        try (Scope scope = span.makeCurrent()) {
            process(byteBuf);
            if (!isError) {
                byteBuf.release();
                subscription.request(1);
            } else {
                byteBuf.release();
                subscription.cancel();
                ctx.error(cause);
            }
            OpenTelemetry openTelemetry = GlobalOpenTelemetry.get();
            openTelemetry.getPropagators();
        } catch (Throwable t) {
            span.setStatus(StatusCode.ERROR, "handle onNext error");
        } finally {
            span.end();
        }
    }

    @Override
    public void onError(Throwable throwable) {
        logger.debug("onError");
        ctx.error(throwable);
    }

    @Override
    public void onComplete() {
        System.out.println("onComplete");
        Span span = Tracing.getTracer().spanBuilder("AbstractSubscriber.onComplete")
                .setParent(io.opentelemetry.context.Context.current().with(Span.current()))
                .startSpan();
        try (Scope scope = span.makeCurrent()) {
            requestComplete();
            ctx.getResponse().status(200).send("Success");
        } catch (Throwable t) {
            span.setStatus(StatusCode.ERROR, "handle biz error");
        } finally {
            span.end();
        }
    }

    protected abstract void process(ByteBuf byteBuf);

    protected void error(Throwable throwable) {
        isError = true;
        cause = throwable;
    }

    protected abstract void requestComplete();

    public String getTopicName() {
        return topicName;
    }

}
