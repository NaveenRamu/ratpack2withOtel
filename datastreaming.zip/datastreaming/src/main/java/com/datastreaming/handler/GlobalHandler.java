package com.datastreaming.handler;

import com.datastreaming.otel.Tracing;
import com.datastreaming.subscriber.JsonSubscriber;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.StatusCode;
import io.opentelemetry.context.Scope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ratpack.core.handling.Context;
import ratpack.core.http.Headers;
import ratpack.core.http.HttpMethod;


public class GlobalHandler extends AbstractHandler {
  private static final Logger logger = LoggerFactory.getLogger(GlobalHandler.class);

  @Override
  public void handleRequest(Context context) throws Exception {
    Span childSpan = Tracing.getTracer().spanBuilder("GlobalHandler.handleRequest")
            .setParent(io.opentelemetry.context.Context.current().with(Span.current()))
            .startSpan();
    try (Scope scope = childSpan.makeCurrent()) {
      childSpan.setAttribute("http.method", context.getRequest().getMethod().getName());
      childSpan.setAttribute("http.url", context.getRequest().getPath());
      AbstractSubscriber jsonSubscriber = new JsonSubscriber(context);
      try (Scope asyncScope = childSpan.makeCurrent()) {
        context.getRequest().getBodyStream().subscribe(jsonSubscriber);
      }
      childSpan.setStatus(StatusCode.OK);
    } catch (Throwable t) {
      childSpan.setStatus(StatusCode.ERROR, "GlobalHandler.handleRequest parent span error");
    } finally {
      childSpan.end();
    }
  }

}
