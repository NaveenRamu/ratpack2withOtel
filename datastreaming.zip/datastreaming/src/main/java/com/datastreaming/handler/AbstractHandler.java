package com.datastreaming.handler;

import ratpack.core.handling.Context;
import ratpack.core.handling.Handler;

public abstract class AbstractHandler implements Handler {
    protected abstract void handleRequest(Context context) throws Exception;

    @Override
    public void handle(Context context) throws Exception {
        handleRequest(context);
    }
}