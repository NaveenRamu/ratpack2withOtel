package com.datastreaming.module;

import com.datastreaming.handler.GlobalHandler;
import com.datastreaming.otel.TracedHandler;
import com.google.inject.AbstractModule;
import com.google.inject.Scopes;

public class AppModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(TracedHandler.class).in(Scopes.SINGLETON);
        bind(GlobalHandler.class).in(Scopes.SINGLETON);
    }
}
