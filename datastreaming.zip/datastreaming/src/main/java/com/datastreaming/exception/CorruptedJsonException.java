package com.datastreaming.exception;

public class CorruptedJsonException extends Exception {

  public CorruptedJsonException(String message) {
    super(message);
  }

}
