package com.datastreaming.otel;

import io.opentelemetry.api.trace.Tracer;

public class Tracing {
    private static final Tracer tracer = OpenTelemetryConfig.initializeOpenTelemetry();

    public static Tracer getTracer() {
        return tracer;
    }
}
