package com.datastreaming.otel;

import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.StatusCode;
import io.opentelemetry.context.Scope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ratpack.core.handling.Context;
import ratpack.core.handling.Handler;

public class TracedHandler implements Handler {

    private static final Logger logger = LoggerFactory.getLogger(TracedHandler.class);

    @Override
    public void handle(Context ctx) throws Exception {
        Span span = Tracing.getTracer().spanBuilder("RootSpan. " + ctx.getRequest().getPath())
                .startSpan();
        try (Scope scope = span.makeCurrent()) {
            span.setAttribute("http.method", ctx.getRequest().getMethod().getName());
            span.setAttribute("http.url", ctx.getRequest().getPath());
            ctx.next();
            span.setStatus(StatusCode.OK);
        } catch (Exception e) {
            logger.error("Error handling request: {}", ctx.getRequest().getPath(), e);
            span.setStatus(StatusCode.ERROR, "Unhandled exception");
            span.recordException(e);
            throw e;
        } finally {
            span.end();
        }
    }
}
